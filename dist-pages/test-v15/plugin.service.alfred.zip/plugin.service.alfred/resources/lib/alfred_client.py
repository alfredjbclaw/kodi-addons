"""HTTP client for the Kodi Bridge server. Uses only stdlib (urllib)."""

import json
import urllib.request
import urllib.error


class AlfredClient:
    def __init__(self, host, port, token, timeout=5):
        self._base = "http://{}:{}".format(host, port)
        self._token = token
        self._timeout = timeout

    def _request(self, method, path, data=None):
        url = self._base + path
        body = json.dumps(data).encode("utf-8") if data is not None else None
        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("Authorization", "Bearer " + self._token)
        if body is not None:
            req.add_header("Content-Type", "application/json")
        resp = urllib.request.urlopen(req, timeout=self._timeout)
        return json.loads(resp.read().decode("utf-8"))

    def get_command(self):
        """Poll for a pending command. Returns dict with 'command' key, or None."""
        result = self._request("GET", "/kodi/queue")
        if result.get("command") is None:
            return None
        return result

    def post_status(self, status_dict):
        """Post current player status. Returns True on success."""
        try:
            self._request("POST", "/kodi/status", status_dict)
            return True
        except Exception:
            return False
